#Showcase for Spiceblue Front-end position
###Author - Rohan Krishna

####Description
Designed based on the inspiration sent via e-mail. No CDN Dependencies for smooth offline testing. Native CSS3 Transitions and few lines of jQuery-based classTogglers.
Material Deisgn-based Color Guidelines. CSS3 transitions ensure smooth performance on mobile devices.

####Package Manager
* Bower

####Libraries
* jQuery

####Further Improvements
* Responsive Optimization

* Use GSAP to enhance Animations

* OnePageScroll for FullScreenScroll Effects

* AngularJS wherever possible 

* Sass or Less Build Systems
